# WiFi Amigo Renta — Android v1.0

Claves de Internet de cada propiedad: agregar, buscar, ver y compartir (WhatsApp, otras apps o código QR
para conectarse escaneando con la cámara). Historial de claves anteriores, PIN opcional y exportación a Excel.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
