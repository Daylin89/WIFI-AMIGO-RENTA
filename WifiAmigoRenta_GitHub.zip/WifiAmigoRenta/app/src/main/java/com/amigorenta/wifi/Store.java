package com.amigorenta.wifi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("wifi", Context.MODE_PRIVATE); }

    static List<JSONObject> loadNets(Context c) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("nets", "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static void saveNets(Context c, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString("nets", a.toString()).apply();
    }

    static int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).apply();
        return n;
    }

    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }

    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static Intent waIntent(Context c, String text) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(text)));
        String pkg = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pkg)) i.setPackage(pkg);
        return i;
    }

    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }

    static String dateTime(long ms) {
        if (ms <= 0) return "—";
        SimpleDateFormat d = new SimpleDateFormat("EEE d MMM yyyy", ES);
        d.setTimeZone(TZ);
        SimpleDateFormat t = new SimpleDateFormat("h:mm a", Locale.US);
        t.setTimeZone(TZ);
        return cap(d.format(new Date(ms))) + ", " + t.format(new Date(ms));
    }

    static String excelDate(long ms) {
        if (ms <= 0) return "";
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setTimeZone(TZ);
        return f.format(new Date(ms));
    }

    static String today() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        f.setTimeZone(TZ);
        return f.format(new Date());
    }
}
