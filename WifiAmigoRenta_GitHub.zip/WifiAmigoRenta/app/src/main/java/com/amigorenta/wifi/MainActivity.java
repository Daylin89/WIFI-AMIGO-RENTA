package com.amigorenta.wifi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, PUR = 0xFF7C3AED;
    static final String[] SECURITY = {"WPA / WPA2", "WPA3", "WEP", "Abierta (sin clave)"};
    static final String[] PROVIDERS = {"Telus", "Shaw", "Rogers", "Bell", "Novus", "Freedom", "Fizz", "Otro"};
    static final int REQ_EXPORT = 71;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int TXT_RAW = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;

    List<JSONObject> nets;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String search = "";
    boolean unlocked = false;
    long pausedAt = 0;

    // =====================================================================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        nets = Store.loadNets(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        fab = tv("＋  Nueva red", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        fab.setOnClickListener(v -> open(() -> netForm(-1)));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);
        if (hasPin()) lockScreen(); else { unlocked = true; openTab(0); }
    }

    @Override
    protected void onPause() {
        super.onPause();
        pausedAt = System.currentTimeMillis();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasPin() && unlocked && pausedAt > 0 && System.currentTimeMillis() - pausedAt > 3 * 60000L) {
            unlocked = false;
            lockScreen();
        }
    }

    boolean hasPin() { return !Store.get(this, "pin", "").isEmpty(); }

    void lockScreen() {
        stack.clear();
        setHeader("WiFi Amigo Renta", "Protegida con PIN", "🔒", false);
        LinearLayout p = vbox();
        p.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView ic = tv("🔒", 48, TXT, false);
        ic.setGravity(Gravity.CENTER);
        c.addView(ic);
        TextView t = tv("Escribe tu PIN", 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        EditText pin = input("PIN", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setGravity(Gravity.CENTER);
        pin.setTextSize(24);
        c.addView(pin);
        p.addView(c);
        Runnable go = () -> {
            if (pin.getText().toString().equals(Store.get(this, "pin", ""))) {
                unlocked = true;
                openTab(0);
            } else {
                pin.setText("");
                toast("PIN incorrecto");
            }
        };
        pin.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) {
                if (e.length() > 0 && e.toString().equals(Store.get(MainActivity.this, "pin", ""))) go.run();
            }
        });
        p.addView(button("Entrar", PRI2, v -> go.run()));
        show(scroll(p), false, false);
        pin.requestFocus();
    }

    // ============================ Navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::netsScreen);
        else open(this::more);
    }

    void goBack() {
        if (!unlocked) { finish(); return; }
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1);
            stack.get(stack.size() - 1).run();
        } else if (tabSel != 0) openTab(0);
        else finish();
    }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, boolean fabOn) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        fab.setVisibility(fabOn ? View.VISIBLE : View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"📶", "Redes"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    // ============================ Lista de redes ============================
    void netsScreen() {
        LinkedHashSet<String> props = new LinkedHashSet<>();
        for (JSONObject n : nets) props.add(n.optString("property").toLowerCase(Store.ES));
        setHeader("Claves de Internet", nets.size() + " redes · " + props.size() + " propiedades", "📶", false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar por dirección, red o proveedor", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = search.trim().toLowerCase(Store.ES);
            List<JSONObject> r = new ArrayList<>();
            for (JSONObject n : nets) {
                String hay = (n.optString("property") + " " + n.optString("unit") + " " + n.optString("ssid") + " "
                        + n.optString("provider") + " " + n.optString("account")).toLowerCase(Store.ES);
                if (q.isEmpty() || hay.contains(q)) r.add(n);
            }
            sortNets(r);
            if (nets.isEmpty()) list.addView(empty("Todavía no hay redes guardadas.\nToca «＋ Nueva red» para agregar la primera."));
            else if (r.isEmpty()) list.addView(empty("No se encontraron redes"));
            String last = null;
            for (JSONObject n : r) {
                String pr = n.optString("property");
                if (last == null || !last.equalsIgnoreCase(pr)) {
                    last = pr;
                    list.addView(sectionTitle("🏠 " + (pr.isEmpty() ? "Sin dirección" : pr), null, null));
                }
                list.addView(netRow(n));
            }
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, true);
    }

    View netRow(JSONObject n) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView ic = tv("📶", 22, PRI2, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(0xFFEAF1FF, 14));
        c.addView(ic, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, dp(6), 0);
        TextView ssid = tv(n.optString("ssid"), 16, TXT, true);
        ssid.setMaxLines(1);
        ssid.setEllipsize(TextUtils.TruncateAt.END);
        r.addView(ssid);
        String sub = join(" · ", n.optString("unit"), n.optString("provider"));
        if (!sub.isEmpty()) r.addView(tv(sub, 13, MUT, false));
        final String pass = n.optString("password");
        final TextView pw = tv(isOpen(n) ? "🔓 Red abierta" : "🔑 " + mask(pass), 14, PUR, true);
        pw.setPadding(0, dp(3), 0, 0);
        r.addView(pw);
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!isOpen(n)) {
            final boolean[] shown = {false};
            TextView eye = tv("👁", 20, MUT, false);
            eye.setPadding(dp(8), dp(8), dp(8), dp(8));
            eye.setOnClickListener(v -> { shown[0] = !shown[0]; pw.setText("🔑 " + (shown[0] ? pass : mask(pass))); });
            c.addView(eye);
            TextView cp = tv("📋", 20, MUT, false);
            cp.setPadding(dp(8), dp(8), dp(4), dp(8));
            cp.setOnClickListener(v -> copy("Clave", pass));
            c.addView(cp);
        }
        final int id = n.optInt("id");
        c.setOnClickListener(v -> open(() -> netDetail(id)));
        return c;
    }

    // ============================ Detalle ============================
    void netDetail(int id) {
        final JSONObject n = find(id);
        if (n == null) { goBack(); return; }
        setHeader(n.optString("property").isEmpty() ? "Red Wi-Fi" : n.optString("property"),
                n.optString("unit").isEmpty() ? null : n.optString("unit"), null, true);
        LinearLayout p = vbox();

        LinearLayout c = card();
        c.addView(tv("Red (nombre del Wi-Fi)", 13, MUT, true));
        LinearLayout sr = hbox();
        TextView ssid = tv(n.optString("ssid"), 22, TXT, true);
        sr.addView(ssid, new LinearLayout.LayoutParams(0, -2, 1f));
        sr.addView(iconBtn("📋", v -> copy("Red", n.optString("ssid"))));
        c.addView(sr);
        c.addView(divider());
        c.addView(tv("Clave", 13, MUT, true));
        final String pass = n.optString("password");
        if (isOpen(n)) {
            c.addView(tv("🔓 Red abierta, no necesita clave", 18, GRN, true));
        } else {
            LinearLayout pr = hbox();
            final TextView pw = tv(mask(pass), 22, PUR, true);
            pw.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            final boolean[] shown = {false};
            pr.addView(pw, new LinearLayout.LayoutParams(0, -2, 1f));
            pr.addView(iconBtn("👁", v -> { shown[0] = !shown[0]; pw.setText(shown[0] ? pass : mask(pass)); }));
            pr.addView(iconBtn("📋", v -> copy("Clave", pass)));
            pw.setOnClickListener(v -> { shown[0] = !shown[0]; pw.setText(shown[0] ? pass : mask(pass)); });
            c.addView(pr);
        }
        c.addView(divider());
        c.addView(info("🔐", "Seguridad", n.optString("security") + (n.optBoolean("hidden") ? " · red oculta" : "")));
        if (!n.optString("provider").isEmpty() || !n.optString("account").isEmpty())
            c.addView(info("🏢", "Proveedor", join(" · ", n.optString("provider"), n.optString("account").isEmpty() ? "" : "Cuenta " + n.optString("account"))));
        if (!n.optString("router").isEmpty()) c.addView(info("📍", "Ubicación del router", n.optString("router")));
        if (!n.optString("notes").isEmpty()) c.addView(info("📝", "Notas", n.optString("notes")));
        c.addView(info("🕘", "Actualizada", Store.dateTime(n.optLong("updated"))));
        p.addView(c);

        p.addView(sectionTitle("Compartir", null, null));
        LinearLayout acts = hbox();
        acts.setPadding(dp(10), 0, dp(10), 0);
        acts.addView(action("💬", "WhatsApp", GRN, 0xFFE3F6E8, v -> launch(Store.waIntent(this, shareText(n)))));
        acts.addView(action("📤", "Otras apps", PRI2, 0xFFEAF1FF, v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, shareText(n));
            launch(Intent.createChooser(i, "Compartir clave"));
        }));
        acts.addView(action("🔳", "Enviar QR", PUR, 0xFFF0E9FF, v -> shareQr(n)));
        acts.addView(action("📋", "Copiar todo", 0xFF0F766E, 0xFFDDF4F1, v -> copy("Wi-Fi", shareText(n))));
        p.addView(acts);

        LinearLayout qc = card();
        qc.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView qt = tv("🔳  Código QR para conectarse", 16, TXT, true);
        qt.setGravity(Gravity.CENTER);
        qc.addView(qt);
        Bitmap qb = qr(wifiQrText(n), 600);
        if (qb != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(qb);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(230), dp(230));
            lp.setMargins(0, dp(10), 0, dp(6));
            qc.addView(iv, lp);
        }
        TextView qh = tv("El inquilino lo escanea con la cámara de su teléfono y se conecta sin escribir la clave.", 13, MUT, false);
        qh.setGravity(Gravity.CENTER);
        qc.addView(qh);
        p.addView(qc);

        JSONArray hist = n.optJSONArray("history");
        if (hist != null && hist.length() > 0) {
            p.addView(sectionTitle("Claves anteriores", null, null));
            LinearLayout hc = card();
            for (int i = hist.length() - 1; i >= 0; i--) {
                JSONObject h = hist.optJSONObject(i);
                if (h == null) continue;
                if (hc.getChildCount() > 0) hc.addView(divider());
                final String old = h.optString("password");
                LinearLayout hr = hbox();
                LinearLayout hv = vbox();
                final TextView ot = tv(mask(old), 15, TXT, true);
                hv.addView(ot);
                hv.addView(tv(join(" · ", h.optString("ssid"), "hasta " + Store.dateTime(h.optLong("until"))), 12, MUT, false));
                hr.addView(hv, new LinearLayout.LayoutParams(0, -2, 1f));
                final boolean[] sh = {false};
                hr.addView(iconBtn("👁", v -> { sh[0] = !sh[0]; ot.setText(sh[0] ? old : mask(old)); }));
                hc.addView(hr);
            }
            p.addView(hc);
        }

        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("✏️  Editar / cambiar clave", PRI2, v -> open(() -> netForm(id))), weightLp(1.6f));
        btns.addView(outline("🗑️", RED, v -> new AlertDialog.Builder(this)
                .setTitle("Eliminar red")
                .setMessage("¿Eliminar la red " + n.optString("ssid") + "?")
                .setPositiveButton("Eliminar", (dlg, w) -> { nets.remove(n); Store.saveNets(this, nets); goBack(); })
                .setNegativeButton("Cancelar", null).show()), weightLp(0.5f));
        p.addView(btns);
        show(scroll(p), false, false);
    }

    View info(String icon, String label, String value) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        r.setPadding(0, dp(4), 0, dp(4));
        TextView i = tv(icon, 16, TXT, false);
        i.setPadding(0, 0, dp(10), 0);
        r.addView(i);
        LinearLayout v = vbox();
        v.addView(tv(label, 12, MUT, true));
        v.addView(tv(value, 15, TXT, false));
        r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }

    TextView iconBtn(String ic, View.OnClickListener l) {
        TextView t = tv(ic, 20, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(0xFFF1F4F9, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(dp(6), 0, 0, 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    String shareText(JSONObject n) {
        StringBuilder b = new StringBuilder("📶 Wi-Fi");
        String where = join(" · ", n.optString("property"), n.optString("unit"));
        if (!where.isEmpty()) b.append(" — ").append(where);
        b.append("\nRed: ").append(n.optString("ssid"));
        b.append(isOpen(n) ? "\nClave: (red abierta)" : "\nClave: " + n.optString("password"));
        b.append("\n\nAmigo Renta");
        return b.toString();
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '\\' || ch == ';' || ch == ',' || ch == ':' || ch == '"') b.append('\\');
            b.append(ch);
        }
        return b.toString();
    }

    String wifiQrText(JSONObject n) {
        String sec = n.optString("security");
        String t = sec.startsWith("Abierta") ? "nopass" : sec.equals("WEP") ? "WEP" : "WPA";
        return "WIFI:T:" + t + ";S:" + esc(n.optString("ssid")) + ";"
                + (t.equals("nopass") ? "" : "P:" + esc(n.optString("password")) + ";")
                + (n.optBoolean("hidden") ? "H:true;" : "") + ";";
    }

    static Bitmap qr(String text, int size) {
        try {
            Map<EncodeHintType, Object> h = new HashMap<>();
            h.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            h.put(EncodeHintType.MARGIN, 2);
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, h);
            int w = m.getWidth(), hh = m.getHeight();
            int[] px = new int[w * hh];
            for (int y = 0; y < hh; y++) for (int x = 0; x < w; x++) px[y * w + x] = m.get(x, y) ? Color.BLACK : Color.WHITE;
            Bitmap b = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
            b.setPixels(px, 0, w, 0, 0, w, hh);
            return b;
        } catch (Exception e) { return null; }
    }

    void shareQr(JSONObject n) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a tocar el botón");
            return;
        }
        Bitmap qb = qr(wifiQrText(n), 800);
        if (qb == null) { toast("No se pudo crear el QR"); return; }
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "wifi_" + n.optString("ssid").replaceAll("[^A-Za-z0-9]", "_") + "_" + System.currentTimeMillis() + ".png");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29)
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Amigo Renta WiFi");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception("sin uri");
            try (OutputStream os = getContentResolver().openOutputStream(u)) { qb.compress(Bitmap.CompressFormat.PNG, 100, os); }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.putExtra(Intent.EXTRA_TEXT, shareText(n) + "\n\n📷 Escanea el código QR con la cámara para conectarte.");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            launch(Intent.createChooser(i, "Enviar QR del Wi-Fi"));
        } catch (Exception e) {
            toast("No se pudo guardar el QR");
        }
    }

    // ============================ Formulario ============================
    void netForm(int id) {
        final JSONObject old = id < 0 ? null : find(id);
        setHeader(old == null ? "Nueva red" : "Editar red", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText prop = input("Ej. 801 E Broadway, Vancouver", TXT_CAP);
        EditText unit = input("Ej. Piso 2 / Sótano / Casa completa", TXT_CAP);
        EditText ssid = input("Ej. AmigoRenta_801", TXT_RAW);
        EditText pass = input("Clave del Wi-Fi", TXT_RAW);
        pass.setTypeface(Typeface.MONOSPACE);
        EditText account = input("Ej. 123456789 (opcional)", InputType.TYPE_CLASS_TEXT);
        EditText router = input("Ej. Closet del pasillo, piso 1", TXT_MULTI);
        EditText notes = input("Ej. Si se cae, desconectar el router 30 segundos", TXT_MULTI);
        TextView sec = picker(SECURITY, old != null ? old.optString("security") : SECURITY[0]);
        TextView prov = picker(PROVIDERS, old != null && !old.optString("provider").isEmpty() ? old.optString("provider") : PROVIDERS[0]);
        Switch hidden = new Switch(this);
        hidden.setText("🙈  Red oculta (no aparece en la lista de redes)");
        hidden.setTextSize(15);
        hidden.setTextColor(TXT);
        hidden.setPadding(0, dp(14), 0, dp(4));
        if (old != null) {
            prop.setText(old.optString("property"));
            unit.setText(old.optString("unit"));
            ssid.setText(old.optString("ssid"));
            pass.setText(old.optString("password"));
            account.setText(old.optString("account"));
            router.setText(old.optString("router"));
            notes.setText(old.optString("notes"));
            hidden.setChecked(old.optBoolean("hidden"));
        }
        c.addView(label("🏠", "Propiedad (dirección)", true));
        c.addView(prop);
        LinkedHashSet<String> props = new LinkedHashSet<>();
        for (JSONObject x : nets) if (!x.optString("property").isEmpty()) props.add(x.optString("property"));
        if (!props.isEmpty() && old == null) {
            LinearLayout pc = hbox();
            int k = 0;
            for (String pr : props) {
                if (k++ >= 10) break;
                pc.addView(chip(pr, false, v -> prop.setText(pr)));
            }
            c.addView(hscroll(pc));
        }
        c.addView(label("🚪", "Unidad / zona (opcional)", false));
        c.addView(unit);
        c.addView(label("📶", "Nombre de la red (Wi-Fi)", true));
        c.addView(ssid);
        c.addView(label("🔑", "Clave", false));
        c.addView(pass);
        TextView gen = tv("🎲  Generar una clave segura", 14, PRI2, true);
        gen.setPadding(0, dp(8), 0, 0);
        gen.setOnClickListener(v -> pass.setText(randomPass()));
        c.addView(gen);
        c.addView(label("🔐", "Seguridad", false));
        c.addView(sec);
        c.addView(hidden);
        c.addView(twoCols(labeled("Proveedor", prov), labeled("Nº de cuenta", account)));
        c.addView(label("📍", "¿Dónde está el router?", false));
        c.addView(router);
        c.addView(label("📝", "Notas (opcional)", false));
        c.addView(notes);

        p.addView(button("Guardar", PRI2, v -> {
            String pr = prop.getText().toString().trim();
            String sd = ssid.getText().toString().trim();
            String pw = pass.getText().toString();
            boolean open = ((String) sec.getTag()).startsWith("Abierta");
            if (pr.isEmpty()) { toast("Escribe la dirección de la propiedad"); return; }
            if (sd.isEmpty()) { toast("Escribe el nombre de la red"); return; }
            if (!open && pw.isEmpty()) { toast("Escribe la clave (o elige «Abierta» en Seguridad)"); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) { put(o, "id", Store.nextId(this)); put(o, "history", new JSONArray()); }
            else if (!old.optString("password").equals(pw) || !old.optString("ssid").equals(sd)) {
                JSONArray h = old.optJSONArray("history");
                if (h == null) { h = new JSONArray(); put(o, "history", h); }
                JSONObject e = new JSONObject();
                put(e, "ssid", old.optString("ssid"));
                put(e, "password", old.optString("password"));
                put(e, "until", System.currentTimeMillis());
                h.put(e);
            }
            put(o, "property", pr);
            put(o, "unit", unit.getText().toString().trim());
            put(o, "ssid", sd);
            put(o, "password", open ? "" : pw);
            put(o, "security", (String) sec.getTag());
            put(o, "hidden", hidden.isChecked());
            put(o, "provider", (String) prov.getTag());
            put(o, "account", account.getText().toString().trim());
            put(o, "router", router.getText().toString().trim());
            put(o, "notes", notes.getText().toString().trim());
            put(o, "updated", System.currentTimeMillis());
            if (old == null) nets.add(o);
            Store.saveNets(this, nets);
            toast("Red guardada ✅");
            goBack();
        }));
        show(scroll(p), false, false);
    }

    static String randomPass() {
        String ch = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
        SecureRandom r = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 12; i++) b.append(ch.charAt(r.nextInt(ch.length())));
        return b.toString();
    }

    // ============================ Más ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("📊", "Exportar a Excel", "Todas las redes y claves en un archivo .xlsx", v -> exportXlsx()));
        c.addView(divider());
        c.addView(menuRow("🔒", hasPin() ? "Cambiar o quitar PIN" : "Proteger con PIN", "Pide un PIN al abrir la app", v -> pinDialog()));
        c.addView(divider());
        c.addView(menuRow("📲", "WhatsApp", Store.get(this, "waApp", "business").equals("business") ? "Se abre con WhatsApp Business" : "Se abre con WhatsApp normal", v -> {
            Store.putS(this, "waApp", Store.get(this, "waApp", "business").equals("business") ? "normal" : "business");
            toast("Cambiado");
            more();
        }));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "WiFi Amigo Renta · versión 1.2", null));
        p.addView(c);
        show(scroll(p), true, false);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void pinDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText a = input("PIN nuevo (4 a 6 números)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        EditText b = input("Repite el PIN", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        box.addView(a);
        box.addView(b);
        AlertDialog.Builder d = new AlertDialog.Builder(this)
                .setTitle(hasPin() ? "Cambiar PIN" : "Proteger con PIN")
                .setView(box)
                .setPositiveButton("Guardar", (dlg, w) -> {
                    String x = a.getText().toString(), y = b.getText().toString();
                    if (x.length() < 4 || x.length() > 6) { toast("El PIN debe tener de 4 a 6 números"); return; }
                    if (!x.equals(y)) { toast("Los PIN no coinciden"); return; }
                    Store.putS(this, "pin", x);
                    toast("PIN guardado 🔒");
                    more();
                })
                .setNegativeButton("Cancelar", null);
        if (hasPin()) d.setNeutralButton("Quitar PIN", (dlg, w) -> { Store.putS(this, "pin", ""); toast("PIN quitado"); more(); });
        d.show();
    }

    // ============================ Excel ============================
    void exportXlsx() {
        if (nets.isEmpty()) { toast("No hay redes para exportar"); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE, "claves_internet_amigo_renta_" + Store.today() + ".xlsx");
        try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                writeXlsx(os);
                toast("Excel guardado ✅");
            } catch (Exception e) {
                toast("No se pudo guardar el archivo");
            }
        }
        pausedAt = 0;
    }

    void writeXlsx(OutputStream os) throws Exception {
        List<List<Object>> rows = new ArrayList<>();
        rows.add(row("Propiedad", "Unidad / zona", "Red (Wi-Fi)", "Clave", "Seguridad", "Oculta", "Proveedor", "Nº de cuenta",
                "Ubicación del router", "Notas", "Actualizada"));
        List<JSONObject> sorted = new ArrayList<>(nets);
        sortNets(sorted);
        for (JSONObject n : sorted)
            rows.add(row(n.optString("property"), n.optString("unit"), n.optString("ssid"), n.optString("password"),
                    n.optString("security"), n.optBoolean("hidden") ? "Sí" : "No", n.optString("provider"), n.optString("account"),
                    n.optString("router"), n.optString("notes"), Store.excelDate(n.optLong("updated"))));
        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String pk = "http://schemas.openxmlformats.org/package/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        zput(z, "[Content_Types].xml", hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "</Types>");
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"" + pk + "\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>"
                + "<sheet name=\"Claves de Internet\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        zput(z, "xl/_rels/workbook.xml.rels", hd + "<Relationships xmlns=\"" + pk + "\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"" + rel + "/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0D3B7A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        zput(z, "xl/worksheets/sheet1.xml", sheetXml(ns, rows, new int[]{32, 18, 22, 20, 14, 8, 12, 16, 28, 30, 17}));
        z.finish();
    }

    static List<Object> row(Object... cells) {
        List<Object> r = new ArrayList<>();
        Collections.addAll(r, cells);
        return r;
    }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                String str = row.get(c) == null ? "" : row.get(c).toString();
                if (str.isEmpty() && r > 0) continue;
                s.append("<c r=\"").append(colName(c)).append(r + 1).append("\" t=\"inlineStr\"").append(r == 0 ? " s=\"1\"" : "")
                        .append("><is><t xml:space=\"preserve\">").append(xml(str)).append("</t></is></c>");
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ Utilidades ============================
    JSONObject find(int id) {
        for (JSONObject n : nets) if (n.optInt("id") == id) return n;
        return null;
    }

    static boolean isOpen(JSONObject n) { return n.optString("security").startsWith("Abierta"); }

    static String mask(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < Math.max(6, Math.min(s.length(), 12)); i++) b.append("•");
        return b.toString();
    }

    static void sortNets(List<JSONObject> l) {
        Collections.sort(l, (x, y) -> {
            int c = x.optString("property").compareToIgnoreCase(y.optString("property"));
            if (c != 0) return c;
            c = x.optString("unit").compareToIgnoreCase(y.optString("unit"));
            if (c != 0) return c;
            return x.optString("ssid").compareToIgnoreCase(y.optString("ssid"));
        });
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    void copy(String label, String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast(label + " copiada 📋");
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    void launch(Intent i) {
        pausedAt = 0;
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    static void put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception e) { }
    }

    void afterRestore() {
        recreate();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
